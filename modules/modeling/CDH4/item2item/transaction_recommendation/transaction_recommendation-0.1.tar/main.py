#!/usr/bin/env python
# -*- coding: utf-8 -*-

from specparser import HiveRuntime

def main():
    hr = HiveRuntime()
    hr.execute("main.hql")
    print("Done")

if __name__ == "__main__":
    main()